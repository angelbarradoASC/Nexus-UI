"""
tests/smoke/test_smoke_desktop.py
-----------------------------------
Smoke tests del modo desktop.
Verifican que los endpoints de tray arrancan y responden correctamente
con y sin DESKTOP_INTERNAL_TOKEN configurado.

Estos tests son smoke — solo verifican que las rutas críticas
no están rotas, no la lógica de negocio completa.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest


@pytest.fixture
def desktop_client(test_config):
    """Cliente con NEXUS_CONTEXT=desktop_app y token interno configurado."""
    import os
    os.environ["DEBUG"] = "true"

    desktop_cfg = test_config.model_copy(update={
        "nexus_context": "desktop_app",
        "desktop_internal_token": "test-internal-token-123",
    })

    mock_redis = AsyncMock()
    mock_redis.ping = AsyncMock(return_value=True)
    mock_redis.lpush = AsyncMock(return_value=1)
    mock_redis.rpop = AsyncMock(return_value=None)
    mock_redis.aclose = AsyncMock()

    from agents.llm_router import LLMResponse, LLMRouter
    mock_router = MagicMock(spec=LLMRouter)
    mock_router.close = AsyncMock()
    mock_router.available_levels = MagicMock(return_value=[0])

    with patch("config.cfg", desktop_cfg), \
         patch("agents.llm_router._router", mock_router):
        from fastapi.testclient import TestClient
        import main as app_module

        from utils.session_auth import SessionAuth
        app_module._session_auth = SessionAuth(desktop_cfg)
        app_module._redis = mock_redis
        app_module.app.state.repo = MagicMock()
        app_module.app.state.repo.disponible = False

        with TestClient(app_module.app, raise_server_exceptions=False) as c:
            yield c, desktop_cfg.desktop_internal_token


class TestDesktopToken:
    def test_ingest_con_token_correcto_ok(self, desktop_client):
        client, token = desktop_client
        resp = client.post(
            "/api/metrics/ingest",
            json={"metrics": {"cpu": 42}, "alerts": []},
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 200

    def test_ingest_sin_token_devuelve_401(self, desktop_client):
        client, _ = desktop_client
        resp = client.post(
            "/api/metrics/ingest",
            json={"metrics": {}, "alerts": []},
            # Sin header Authorization
        )
        assert resp.status_code == 401

    def test_ingest_con_token_incorrecto_devuelve_403(self, desktop_client):
        client, _ = desktop_client
        resp = client.post(
            "/api/metrics/ingest",
            json={"metrics": {}, "alerts": []},
            headers={"Authorization": "Bearer token-equivocado"},
        )
        assert resp.status_code == 403

    def test_quick_action_con_token_ok(self, desktop_client):
        client, token = desktop_client
        resp = client.post(
            "/api/quick-action",
            json={"action": "fichar_entrada"},
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 200

    def test_metrics_endpoint_disponible_en_desktop(self, desktop_client):
        client, _ = desktop_client

        # Login para poder acceder a /api/metrics
        client.post("/login", data={"username": "testuser", "password": "testpass"}, follow_redirects=False)
        resp = client.get("/api/metrics")
        assert resp.status_code == 200
        body = resp.json()
        assert body["available"] is True


class TestSmoke:
    def test_health_ok(self, desktop_client):
        client, _ = desktop_client
        resp = client.get("/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"
        assert resp.json()["context"] == "desktop_app"

    def test_login_page_carga(self, desktop_client):
        client, _ = desktop_client
        resp = client.get("/login")
        assert resp.status_code == 200

    def test_favicon_no_rompe(self, desktop_client):
        client, _ = desktop_client
        resp = client.get("/favicon.ico")
        assert resp.status_code == 200
