# NEXUS-UI — Batería de Tests

Guía de referencia para ingenieros: estructura, ejecución, cobertura y mejoras.

---

## A) Estructura de directorios

```
tests/
├── conftest.py                         ← Fixtures globales (auth, LLM mocks, app client)
├── test_llm_parser.py                  ← Parser de thinking / XML
│
├── unit/                               ← Lógica pura, sin I/O real
│   ├── test_base_agent.py              ← AgentResult, BaseAgent (contrato)
│   ├── test_generation_agent.py        ← GenerationAgent (LLM general)
│   ├── test_ssh_agent.py               ← SSHAgent + _ejecutar_diagnostico
│   ├── test_web_agent.py               ← WebAgent (DuckDuckGo + síntesis)
│   ├── test_host_resolver.py           ← HostResolver (known_hosts → DNS)
│   ├── test_mode_agents.py             ← AnalystAgent, CoderAgent, ResearcherAgent
│   ├── test_skills_registry.py         ← SkillsRegistry, SkillDefinition, validación
│   ├── test_intention_agent.py         ← IntentionAgent (clasificación de intenciones)
│   ├── test_llm_router.py              ← LLMRouter (niveles, reintentos, métricas)
│   ├── test_config.py                  ← AppConfig (parseo, validación, propiedades)
│   ├── test_session_auth.py            ← SessionAuth (bcrypt, TTL, sesiones)
│   └── test_credential_store.py        ← CredentialStore (Fernet, validación)
│
├── integration/                        ← Tests con múltiples componentes reales
│   ├── test_orchestration.py           ← OrchestrationAgent (flujo completo)
│   ├── test_orchestration_stream.py    ← process_query_stream(), agent_override
│   ├── test_conversation_repository.py ← ConversationRepository (CRUD MongoDB mock)
│   └── test_worker.py                  ← _procesar_tarea() (worker Redis mock)
│
├── e2e/                                ← API completa (FastAPI TestClient)
│   ├── test_api.py                     ← Endpoints principales, auth, historial
│   └── test_api_crud.py                ← DELETE/PATCH/POST nuevos + SSE /chat/stream
│
└── smoke/
    └── test_smoke_desktop.py           ← Endpoints /api/metrics, /api/quick-action
```

**Total: 15 ficheros de test | ~300 funciones test_***

---

## B) Instrucciones de ejecución

### Instalación

```bash
cd C:\DEV\Nexus-UI
pip install -r app/requirements/dev.txt
```

Dependencias de test clave (ya en dev.txt):
```
pytest>=8.0
pytest-asyncio>=0.23
pytest-cov>=5.0
httpx>=0.27          # para TestClient async
```

### Variables de entorno (ya configuradas en conftest.py)

No se necesitan variables externas para tests unitarios e integration.
Los tests smoke y e2e tampoco requieren servicios reales — todo mockeado.

```bash
# Opcional: forzar modo debug
export DEBUG=true
```

### Ejecutar todos los tests

```bash
cd C:\DEV\Nexus-UI
pytest tests/ -v
```

### Por capa

```bash
# Solo unit tests (más rápidos, sin I/O)
pytest tests/unit/ -v

# Solo integration
pytest tests/integration/ -v

# Solo E2E
pytest tests/e2e/ -v

# Solo smoke (requiere app arrancada si no se mockea)
pytest tests/smoke/ -v
```

### Con cobertura

```bash
pytest tests/ \
  --cov=app \
  --cov-report=term-missing \
  --cov-report=html:coverage_html \
  -v
```

El reporte HTML se genera en `coverage_html/index.html`.

### Tests específicos

```bash
# Un fichero
pytest tests/unit/test_ssh_agent.py -v

# Una clase
pytest tests/unit/test_ssh_agent.py::TestEjecutarDiagnosticoSSH -v

# Un test concreto
pytest tests/unit/test_ssh_agent.py::TestEjecutarDiagnosticoSSH::test_cierra_cliente_tras_ejecucion -v

# Tests con keyword
pytest tests/ -k "stream" -v
pytest tests/ -k "error or fallo" -v
```

### Configuración pytest (pytest.ini / pyproject.toml)

```ini
[pytest]
asyncio_mode = auto
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
filterwarnings =
    ignore::DeprecationWarning
    ignore::PendingDeprecationWarning
```

### CI/CD (GitHub Actions ejemplo)

```yaml
- name: Run tests
  run: |
    pip install -r app/requirements/dev.txt
    pytest tests/ \
      --cov=app \
      --cov-report=xml \
      --junitxml=test-results.xml \
      -v --tb=short
  env:
    DEBUG: "true"
    APP_USERS: "testuser:testpass"
    SECRET_KEY: "ci-test-secret-key-32chars-min!!"
    CREDENTIAL_STORE_KEY: "ci-encryption-key-32chars-min!!"
    LLM_API_BASE_URL: "http://localhost:1234/v1"
    REDIS_HOST: "localhost"
    MONGO_URI: ""
```

---

## C) Cobertura por módulo

| Módulo | Tests | Cobertura estimada |
|--------|-------|--------------------|
| `base_agent.py` | test_base_agent.py (11) | Alta |
| `generation_agent.py` | test_generation_agent.py (15) | Alta |
| `ssh_agent.py` | test_ssh_agent.py (22) | Alta |
| `web_agent.py` | test_web_agent.py (18) | Alta |
| `analyst_agent.py` | test_mode_agents.py (7) | Media-Alta |
| `coder_agent.py` | test_mode_agents.py (6) | Media-Alta |
| `researcher_agent.py` | test_mode_agents.py (9) | Media-Alta |
| `intention_agent.py` | test_intention_agent.py (14) | Alta |
| `orchestration_agent.py` | test_orchestration*.py (30) | Alta |
| `llm_router.py` | test_llm_router.py (8) | Media |
| `host_resolver.py` | test_host_resolver.py (24) | Alta |
| `credential_store.py` | test_credential_store.py (18) | Alta |
| `skills_registry.py` | test_skills_registry.py (33) | Alta |
| `conversation_repository.py` | test_conversation_repository.py (36) | Alta |
| `worker.py` | test_worker.py (15) | Media-Alta |
| `config.py` | test_config.py (19) | Alta |
| `session_auth.py` | test_session_auth.py (17) | Alta |
| `main.py` | test_api*.py (51) | Media-Alta |
| `llm_parser.py` | test_llm_parser.py (5) | Media |

**Módulos sin tests directos** (cobertura indirecta vía agentes):
- `tools/jira_client.py` — cubierto indirectamente por JiraAgent
- `tools/web_fetch.py` — mockeado en test_web_agent.py
- `tools/web_search.py` — mockeado en test_web_agent.py
- `exceptions.py` — clases simples, cobertura en E2E
- `metrics.py` — cubierto en smoke tests

---

## D) Análisis de testabilidad y mejoras propuestas

### Partes difíciles de testear actualmente

#### 1. `worker/worker.py` — función `main()`
La función `main()` es un loop infinito con SIGINT/SIGTERM. Es difícil de testear end-to-end sin complejidad.

**Estado actual:** `_procesar_tarea()` está bien aislada y testeada.
**Mejora:** Extraer el loop en una clase `WorkerLoop` con método `run_once()` testeable.

#### 2. `agents/tools/jira_client.py` — cliente REST externo
Las llamadas httpx a Jira Cloud no tienen tests directos.

**Mejora propuesta:**
```python
# Añadir fixture en conftest.py:
@pytest.fixture
def mock_jira_client():
    with respx.mock:
        respx.post("https://jira.example.com/rest/api/3/issue").mock(
            return_value=httpx.Response(201, json={"key": "PRJ-42", "id": "10001"})
        )
        yield
```

#### 3. `agents/ssh_agent.py` — Paramiko con known_hosts reales
La política de host keys depende del filesystem (`~/.ssh/known_hosts`).

**Mejora:** Convertir `_KNOWN_HOSTS_FILE` en un parámetro inyectable en lugar de constante global.

#### 4. `app/main.py` — SSE endpoint con streaming real
`TestClient` de Starlette consume el stream completo. No testea latencia ni reconexión.

**Mejora:** Tests de SSE con `httpx.AsyncClient` en modo streaming:
```python
async with httpx.AsyncClient(app=app, base_url="http://test") as client:
    async with client.stream("GET", "/chat/stream/t1") as r:
        async for line in r.aiter_lines():
            ...
```

#### 5. `researcher_agent.py` — Integración web + LLM en serie
El flujo "búsqueda web → enriquecimiento → síntesis" no está cubierto end-to-end.

**Mejora:** Test de integración con WebAgent real (mockeando solo httpx, no DuckDuckGo entero).

---

### Refactorizaciones para mejorar testabilidad

| Componente | Problema | Refactor sugerido |
|------------|----------|-------------------|
| `HostResolver.__init__` | Hardcodea `/app/data/known_hosts.json` | Recibir `hosts_file: Path` como parámetro |
| `SSHAgent._ejecutar_diagnostico` | Crea `paramiko.SSHClient()` internamente | Inyectar `client_factory: Callable` |
| `worker.main()` | Loop monolítico con Redis + Orchestrator acoplados | Extraer a clase `WorkerLoop(redis, orchestrator)` |
| `JiraClient.__init__` | Lee de `os.environ` directamente | Recibir `AppConfig` inyectado |
| `skills_registry.get_registry()` | Singleton sin reset en tests | Añadir `_reset_singleton()` para test teardown |

---

### Gaps de cobertura pendientes (prioridad)

1. **`jira_client.py`** — `create_issue()`, `get_issue()`, `add_comment()`, `search_issues()` con respx mock
2. **`jira_agent.py`** — Flujo completo con JiraClient mockeado
3. **`web_fetch.py` / `web_search.py`** — Tests directos con respx/httpx mock
4. **Tests de regresión** — Fijar los contratos de OrchestrationResult para detectar cambios de API
5. **Tests de carga del worker** — Verificar que el worker procesa N tareas concurrentes sin memory leaks

---

### Convenciones de naming adoptadas

```
TestNombreClase          ← Clase de test para una clase del sistema
TestFlujoEspecifico      ← Grupo de tests para un flujo o escenario
test_accion_condicion    ← test_devuelve_none_si_objectid_invalido
test_accion_resultado    ← test_toggle_de_false_a_true
```

### Fixtures compartidas (conftest.py)

| Fixture | Scope | Descripción |
|---------|-------|-------------|
| `test_config` | session | AppConfig con valores seguros de test |
| `session_auth` | function | SessionAuth inicializado |
| `mock_llm_router` | function | LLMRouter con call() mockeado (éxito) |
| `mock_llm_router_error` | function | LLMRouter que siempre devuelve error |
| `mock_llm_router_stream` | function | LLMRouter con call_stream() como async generator |
| `credential_store` | function | CredentialStore en tmp_path |
| `app_client` | function | FastAPI TestClient con Redis/MongoDB mockeados |
