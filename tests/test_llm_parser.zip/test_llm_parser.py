# test_llm_parser.py
# Tests de ejemplo para el LLMResponseParser

from llm_parser import LLMResponseParser, clean_llm_response

def test_xml_tags():
    """Test con tags XML estilo DeepSeek/QwQ"""
    response = """<thinking>
El usuario me pregunta "hola que tal"
Probablemente es hispanohablante
Debo responder en español de forma casual
La respuesta apropiada sería un saludo amigable
</thinking>

¡Hola! ¿Cómo estás? ¿En qué puedo ayudarte hoy?"""

    parser = LLMResponseParser()
    result = parser.parse(response, debug=True)
    
    print("=" * 60)
    print("TEST 1: Tags XML")
    print("=" * 60)
    print(f"Respuesta original ({len(response)} chars):")
    print(response)
    print("\n" + "-" * 60)
    print(f"Respuesta limpia ({len(result['clean_response'])} chars):")
    print(result['clean_response'])
    print(f"\nThinking detectado: {result['had_thinking']}")
    if result['had_thinking']:
        print(f"Thinking extraído:")
        print(result['thinking_process'])
    print("\n")


def test_markdown_headers():
    """Test con headers markdown"""
    response = """### Thinking Process

Let me analyze this query step by step.
The user is asking about server diagnostics.
I should provide a structured response.

## Response

Para diagnosticar el servidor PROD-01, necesitarás:

1. Verificar CPU y memoria
2. Revisar logs del sistema
3. Comprobar conectividad de red"""

    result = clean_llm_response(response, debug=True)
    
    print("=" * 60)
    print("TEST 2: Headers Markdown")
    print("=" * 60)
    print(f"Respuesta original ({len(response)} chars):")
    print(response)
    print("\n" + "-" * 60)
    print(f"Respuesta limpia ({len(result)} chars):")
    print(result)
    print("\n")


def test_text_patterns():
    """Test con patrones de texto plano"""
    response = """Let me think about this carefully...
The user wants to know about ticket INC000456.
I need to provide relevant information.
This is an HDA ticket based on the format.

El ticket INC000456 está actualmente en estado "En Progreso". 
Fue creado hace 2 horas y asignado al equipo de infraestructura."""

    result = clean_llm_response(response, debug=True)
    
    print("=" * 60)
    print("TEST 3: Texto Plano")
    print("=" * 60)
    print(f"Respuesta original ({len(response)} chars):")
    print(response)
    print("\n" + "-" * 60)
    print(f"Respuesta limpia ({len(result)} chars):")
    print(result)
    print("\n")


def test_multiple_formats():
    """Test con múltiples formatos mezclados"""
    response = """<thinking>
Usuario pregunta por servidor PROD-01
Necesito verificar qué información necesita
</thinking>

### Analysis
This seems to be a diagnostic request.
The server name follows standard naming convention.

<reflection>
Should I ask for more details or provide general diagnostics?
I'll provide general steps first.
</reflection>

Para diagnosticar PROD-01:

- **CPU**: Ejecuta `top` o `htop`
- **Memoria**: Verifica con `free -h`
- **Disco**: Usa `df -h`
- **Red**: Comprueba con `ping` y `netstat`"""

    result = clean_llm_response(response, debug=True)
    
    print("=" * 60)
    print("TEST 4: Múltiples Formatos Mezclados")
    print("=" * 60)
    print(f"Respuesta original ({len(response)} chars):")
    print(response)
    print("\n" + "-" * 60)
    print(f"Respuesta limpia ({len(result)} chars):")
    print(result)
    print("\n")


def test_no_thinking():
    """Test con respuesta normal sin thinking"""
    response = """Claro, puedo ayudarte con eso.

El servidor PROD-01 está funcionando correctamente según los últimos checks."""

    result = clean_llm_response(response, debug=True)
    
    print("=" * 60)
    print("TEST 5: Sin Thinking (respuesta normal)")
    print("=" * 60)
    print(f"Respuesta original ({len(response)} chars):")
    print(response)
    print("\n" + "-" * 60)
    print(f"Respuesta limpia ({len(result)} chars):")
    print(result)
    print("\n")


if __name__ == "__main__":
    print("\n🧪 TESTS DEL LLM RESPONSE PARSER\n")
    
    test_xml_tags()
    test_markdown_headers()
    test_text_patterns()
    test_multiple_formats()
    test_no_thinking()
    
    print("=" * 60)
    print("✅ Todos los tests completados")
    print("=" * 60)
