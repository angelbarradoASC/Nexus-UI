"""
tests/e2e/test_api_crud.py
----------------------------
Tests E2E para:
  - DELETE /api/conversation/{id}
  - PATCH  /api/conversation/{id}/folder
  - POST   /api/conversation/{id}/favorite
  - POST   /api/canvas/save
  - GET    /chat/stream/{task_id}  (SSE)

Todos los tests usan MongoDB mockeado para no necesitar BBDD real.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient


# ── Helpers y fixtures ────────────────────────────────────────────────────────

_FAKE_OID = "507f1f77bcf86cd799439011"
_FAKE_CONV = {
    "_id":      _FAKE_OID,
    "username": "testuser",
    "query":    "Consulta de test",
    "response": "Respuesta de test",
    "thinking": "",
    "favorite": False,
    "folder":   "",
}


def _make_app_client_with_mongo(test_config, mock_llm_router, conv_doc=None):
    """
    Crea un TestClient con ConversationRepository mockeado.
    conv_doc: el documento que devuelve repo.obtener(); None simula no encontrado.
    """
    from fastapi.testclient import TestClient

    mock_redis = AsyncMock()
    mock_redis.ping      = AsyncMock(return_value=True)
    mock_redis.lpush     = AsyncMock(return_value=1)
    mock_redis.rpop      = AsyncMock(return_value=None)
    mock_redis.aclose    = AsyncMock()

    mock_repo = MagicMock()
    mock_repo.disponible = True
    mock_repo.obtener         = AsyncMock(return_value=conv_doc)
    mock_repo.eliminar        = AsyncMock(return_value=True)
    mock_repo.actualizar_carpeta = AsyncMock(return_value=True)
    mock_repo.toggle_favorito = AsyncMock(return_value=True)
    mock_repo.guardar_canvas  = AsyncMock(return_value=True)
    mock_repo.listar          = AsyncMock(return_value=[])
    mock_repo.formatear_para_api = MagicMock(return_value=[])

    with patch("main._redis", mock_redis), \
         patch("main.cfg", test_config), \
         patch("agents.llm_router._router", mock_llm_router):
        import main as app_module
        from utils.session_auth import SessionAuth
        app_module._session_auth = SessionAuth(test_config)
        app_module._redis = mock_redis
        app_module.app.state.repo = mock_repo

        with TestClient(app_module.app, raise_server_exceptions=True) as client:
            # Login
            client.post("/login", data={"username": "testuser", "password": "testpass"},
                        follow_redirects=False)
            yield client, mock_repo


@pytest.fixture
def authed_client_with_conv(test_config, mock_llm_router):
    """Cliente autenticado con una conversación existente mockeada."""
    yield from _make_app_client_with_mongo(test_config, mock_llm_router, _FAKE_CONV)


@pytest.fixture
def authed_client_no_conv(test_config, mock_llm_router):
    """Cliente autenticado pero sin conversación (obtener devuelve None)."""
    yield from _make_app_client_with_mongo(test_config, mock_llm_router, conv_doc=None)


# ═══════════════════════════════════════════════════════════════════════════════
# DELETE /api/conversation/{id}
# ═══════════════════════════════════════════════════════════════════════════════

class TestDeleteConversation:

    def test_delete_existente_devuelve_200(self, authed_client_with_conv):
        client, _ = authed_client_with_conv
        resp = client.delete(f"/api/conversation/{_FAKE_OID}")
        assert resp.status_code == 200

    def test_delete_existente_respuesta_json(self, authed_client_with_conv):
        client, _ = authed_client_with_conv
        resp = client.delete(f"/api/conversation/{_FAKE_OID}")
        data = resp.json()
        assert data["status"] == "success"
        assert data["deleted"] == _FAKE_OID

    def test_delete_llama_a_repo_eliminar(self, authed_client_with_conv):
        client, mock_repo = authed_client_with_conv
        client.delete(f"/api/conversation/{_FAKE_OID}")
        mock_repo.eliminar.assert_called_once_with(_FAKE_OID)

    def test_delete_no_encontrado_devuelve_404(self, authed_client_no_conv):
        client, _ = authed_client_no_conv
        resp = client.delete(f"/api/conversation/{_FAKE_OID}")
        assert resp.status_code == 404

    def test_delete_sin_auth_devuelve_401(self, test_config, mock_llm_router):
        gen = _make_app_client_with_mongo(test_config, mock_llm_router, _FAKE_CONV)
        client, _ = next(gen)
        # Eliminar cookie de sesión
        client.cookies.clear()
        resp = client.delete(f"/api/conversation/{_FAKE_OID}")
        assert resp.status_code == 401

    def test_delete_otro_usuario_devuelve_403(self, test_config, mock_llm_router):
        """Un usuario no puede borrar conversaciones ajenas."""
        conv_ajena = {**_FAKE_CONV, "username": "otro_usuario"}
        gen = _make_app_client_with_mongo(test_config, mock_llm_router, conv_ajena)
        client, _ = next(gen)
        resp = client.delete(f"/api/conversation/{_FAKE_OID}")
        assert resp.status_code == 403

    def test_delete_cuando_repo_falla_devuelve_500(self, test_config, mock_llm_router):
        gen = _make_app_client_with_mongo(test_config, mock_llm_router, _FAKE_CONV)
        client, mock_repo = next(gen)
        mock_repo.eliminar = AsyncMock(return_value=False)
        resp = client.delete(f"/api/conversation/{_FAKE_OID}")
        assert resp.status_code == 500


# ═══════════════════════════════════════════════════════════════════════════════
# PATCH /api/conversation/{id}/folder
# ═══════════════════════════════════════════════════════════════════════════════

class TestUpdateConversationFolder:

    def test_patch_folder_devuelve_200(self, authed_client_with_conv):
        client, _ = authed_client_with_conv
        resp = client.patch(
            f"/api/conversation/{_FAKE_OID}/folder",
            json={"folder": "Proyecto Alpha"},
        )
        assert resp.status_code == 200

    def test_patch_folder_respuesta_json(self, authed_client_with_conv):
        client, _ = authed_client_with_conv
        resp = client.patch(
            f"/api/conversation/{_FAKE_OID}/folder",
            json={"folder": "Trabajo"},
        )
        data = resp.json()
        assert data["status"] == "success"
        assert data["folder"] == "Trabajo"
        assert data["conversation_id"] == _FAKE_OID

    def test_patch_folder_llama_a_repo(self, authed_client_with_conv):
        client, mock_repo = authed_client_with_conv
        client.patch(
            f"/api/conversation/{_FAKE_OID}/folder",
            json={"folder": "MiCarpeta"},
        )
        mock_repo.actualizar_carpeta.assert_called_once_with(_FAKE_OID, "MiCarpeta")

    def test_patch_folder_no_encontrado_devuelve_404(self, authed_client_no_conv):
        client, _ = authed_client_no_conv
        resp = client.patch(
            f"/api/conversation/{_FAKE_OID}/folder",
            json={"folder": "Carpeta"},
        )
        assert resp.status_code == 404

    def test_patch_folder_sin_auth_devuelve_401(self, test_config, mock_llm_router):
        gen = _make_app_client_with_mongo(test_config, mock_llm_router, _FAKE_CONV)
        client, _ = next(gen)
        client.cookies.clear()
        resp = client.patch(
            f"/api/conversation/{_FAKE_OID}/folder",
            json={"folder": "X"},
        )
        assert resp.status_code == 401

    def test_patch_folder_body_requerido(self, authed_client_with_conv):
        """Sin body JSON el endpoint debe fallar (422 o 400)."""
        client, _ = authed_client_with_conv
        resp = client.patch(f"/api/conversation/{_FAKE_OID}/folder")
        assert resp.status_code in (400, 422)


# ═══════════════════════════════════════════════════════════════════════════════
# POST /api/conversation/{id}/favorite
# ═══════════════════════════════════════════════════════════════════════════════

class TestToggleConversationFavorite:

    def test_toggle_favorite_devuelve_200(self, authed_client_with_conv):
        client, _ = authed_client_with_conv
        resp = client.post(f"/api/conversation/{_FAKE_OID}/favorite")
        assert resp.status_code == 200

    def test_toggle_favorite_respuesta_json(self, authed_client_with_conv):
        client, _ = authed_client_with_conv
        resp = client.post(f"/api/conversation/{_FAKE_OID}/favorite")
        data = resp.json()
        assert data["status"] == "success"
        assert "favorite" in data
        assert data["conversation_id"] == _FAKE_OID

    def test_toggle_favorite_llama_a_repo(self, authed_client_with_conv):
        client, mock_repo = authed_client_with_conv
        client.post(f"/api/conversation/{_FAKE_OID}/favorite")
        mock_repo.toggle_favorito.assert_called_once_with(_FAKE_OID)

    def test_toggle_favorite_no_encontrado_devuelve_404(self, authed_client_no_conv):
        client, _ = authed_client_no_conv
        resp = client.post(f"/api/conversation/{_FAKE_OID}/favorite")
        assert resp.status_code == 404

    def test_toggle_favorite_sin_auth_devuelve_401(self, test_config, mock_llm_router):
        gen = _make_app_client_with_mongo(test_config, mock_llm_router, _FAKE_CONV)
        client, _ = next(gen)
        client.cookies.clear()
        resp = client.post(f"/api/conversation/{_FAKE_OID}/favorite")
        assert resp.status_code == 401

    def test_toggle_favorite_cuando_repo_devuelve_none_da_500(
        self, test_config, mock_llm_router
    ):
        gen = _make_app_client_with_mongo(test_config, mock_llm_router, _FAKE_CONV)
        client, mock_repo = next(gen)
        mock_repo.toggle_favorito = AsyncMock(return_value=None)
        resp = client.post(f"/api/conversation/{_FAKE_OID}/favorite")
        assert resp.status_code == 500

    def test_toggle_devuelve_valor_booleano(self, authed_client_with_conv):
        """El campo favorite debe ser True o False, nunca None."""
        client, mock_repo = authed_client_with_conv
        mock_repo.toggle_favorito = AsyncMock(return_value=True)
        resp = client.post(f"/api/conversation/{_FAKE_OID}/favorite")
        assert resp.json()["favorite"] is True


# ═══════════════════════════════════════════════════════════════════════════════
# POST /api/canvas/save
# ═══════════════════════════════════════════════════════════════════════════════

class TestSaveCanvas:

    def _canvas_payload(self, conv_id=_FAKE_OID, content="print('hello')", canvas_type="code"):
        return {"conversation_id": conv_id, "content": content, "type": canvas_type}

    def test_canvas_save_devuelve_200(self, authed_client_with_conv):
        client, _ = authed_client_with_conv
        resp = client.post("/api/canvas/save", json=self._canvas_payload())
        assert resp.status_code == 200

    def test_canvas_save_respuesta_json(self, authed_client_with_conv):
        client, _ = authed_client_with_conv
        resp = client.post("/api/canvas/save", json=self._canvas_payload())
        data = resp.json()
        assert data["status"] == "success"

    def test_canvas_save_llama_a_repo(self, authed_client_with_conv):
        client, mock_repo = authed_client_with_conv
        client.post("/api/canvas/save", json=self._canvas_payload(
            content="SELECT * FROM users", canvas_type="code"
        ))
        mock_repo.guardar_canvas.assert_called_once_with(
            _FAKE_OID, "SELECT * FROM users", "code"
        )

    def test_canvas_save_sin_conversation_id_devuelve_400(self, authed_client_with_conv):
        client, _ = authed_client_with_conv
        resp = client.post("/api/canvas/save", json={"content": "algo", "type": "code"})
        assert resp.status_code == 400

    def test_canvas_save_conversacion_no_encontrada_devuelve_404(self, authed_client_no_conv):
        client, _ = authed_client_no_conv
        resp = client.post("/api/canvas/save", json=self._canvas_payload())
        assert resp.status_code == 404

    def test_canvas_save_sin_auth_devuelve_401(self, test_config, mock_llm_router):
        gen = _make_app_client_with_mongo(test_config, mock_llm_router, _FAKE_CONV)
        client, _ = next(gen)
        client.cookies.clear()
        resp = client.post("/api/canvas/save", json=self._canvas_payload())
        assert resp.status_code == 401

    def test_canvas_save_tipo_text(self, authed_client_with_conv):
        """El tipo 'text' también debe ser aceptado."""
        client, mock_repo = authed_client_with_conv
        resp = client.post("/api/canvas/save", json=self._canvas_payload(
            content="Texto libre", canvas_type="text"
        ))
        assert resp.status_code == 200
        mock_repo.guardar_canvas.assert_called_once_with(_FAKE_OID, "Texto libre", "text")


# ═══════════════════════════════════════════════════════════════════════════════
# GET /chat/stream/{task_id}  — SSE endpoint
# ═══════════════════════════════════════════════════════════════════════════════

class TestChatStreamEndpoint:
    """
    Tests para el SSE endpoint.

    La respuesta en streaming con TestClient se lee completa;
    verificamos headers correctos y comportamiento de autenticación.
    """

    def _make_mock_pubsub(self, messages: list[dict]):
        """
        Crea un mock de pubsub que emite una lista de mensajes y luego None.
        messages: lista de dicts con la estructura que devuelve get_message().
        """
        pubsub = AsyncMock()
        pubsub.subscribe   = AsyncMock()
        pubsub.unsubscribe = AsyncMock()
        pubsub.aclose      = AsyncMock()
        # get_message es síncrono en el código real
        call_count = [0]
        def _get_message(ignore_subscribe_messages=True):
            idx = call_count[0]
            call_count[0] += 1
            if idx < len(messages):
                return messages[idx]
            return None
        pubsub.get_message = MagicMock(side_effect=_get_message)
        return pubsub

    def test_stream_sin_auth_devuelve_401(self, test_config, mock_llm_router):
        gen = _make_app_client_with_mongo(test_config, mock_llm_router, None)
        client, _ = next(gen)
        client.cookies.clear()
        resp = client.get("/chat/stream/fake-task-id")
        assert resp.status_code == 401

    def test_stream_headers_correcto(self, authed_client_with_conv):
        """El SSE endpoint debe devolver Content-Type: text/event-stream."""
        client, _ = authed_client_with_conv

        # Mockear redis con pubsub que emite done inmediatamente
        done_msg = {
            "type":    "message",
            "data":    json.dumps({"type": "done", "content": "Listo"}),
            "channel": "nexus_stream:test-task",
        }
        mock_pubsub = self._make_mock_pubsub([done_msg])

        import main as app_module
        app_module._redis.pubsub = MagicMock(return_value=mock_pubsub)

        resp = client.get("/chat/stream/test-task-id")
        assert "text/event-stream" in resp.headers.get("content-type", "")

    def test_stream_headers_no_cache(self, authed_client_with_conv):
        """El SSE endpoint debe incluir Cache-Control: no-cache."""
        client, _ = authed_client_with_conv

        done_msg = {
            "type":    "message",
            "data":    json.dumps({"type": "done"}),
            "channel": "nexus_stream:test-task",
        }
        mock_pubsub = self._make_mock_pubsub([done_msg])

        import main as app_module
        app_module._redis.pubsub = MagicMock(return_value=mock_pubsub)

        resp = client.get("/chat/stream/test-task-id")
        assert resp.headers.get("cache-control") == "no-cache"

    def test_stream_emite_datos_sse(self, authed_client_with_conv):
        """El SSE endpoint debe emitir eventos en formato 'data: {...}\\n\\n'."""
        client, _ = authed_client_with_conv

        chunk_msg = {
            "type":    "message",
            "data":    json.dumps({"type": "chunk", "content": "Hola "}),
            "channel": "nexus_stream:t",
        }
        done_msg = {
            "type":    "message",
            "data":    json.dumps({"type": "done"}),
            "channel": "nexus_stream:t",
        }
        mock_pubsub = self._make_mock_pubsub([chunk_msg, done_msg])

        import main as app_module
        app_module._redis.pubsub = MagicMock(return_value=mock_pubsub)

        resp = client.get("/chat/stream/test-task")
        # La respuesta completa debe contener las líneas SSE
        assert "data:" in resp.text
        assert "Hola" in resp.text

    def test_stream_termina_con_evento_done(self, authed_client_with_conv):
        """El stream debe contener el evento 'done' y terminar."""
        client, _ = authed_client_with_conv

        done_msg = {
            "type":    "message",
            "data":    json.dumps({"type": "done", "response": "respuesta final"}),
            "channel": "nexus_stream:t",
        }
        mock_pubsub = self._make_mock_pubsub([done_msg])

        import main as app_module
        app_module._redis.pubsub = MagicMock(return_value=mock_pubsub)

        resp = client.get("/chat/stream/test-task")
        assert "done" in resp.text

    def test_stream_termina_con_evento_error(self, authed_client_with_conv):
        """El evento 'error' también debe cerrar el stream."""
        client, _ = authed_client_with_conv

        error_msg = {
            "type":    "message",
            "data":    json.dumps({"type": "error", "content": "Fallo interno"}),
            "channel": "nexus_stream:t",
        }
        mock_pubsub = self._make_mock_pubsub([error_msg])

        import main as app_module
        app_module._redis.pubsub = MagicMock(return_value=mock_pubsub)

        resp = client.get("/chat/stream/test-task")
        assert "error" in resp.text


# ═══════════════════════════════════════════════════════════════════════════════
# Tests de MongoDB no disponible — 503 en todos los endpoints
# ═══════════════════════════════════════════════════════════════════════════════

class TestCrudEndpointsSinMongo:
    """
    Cuando MongoDB no está disponible (repo.disponible=False),
    todos los endpoints CRUD deben devolver 503.
    """

    @pytest.fixture
    def client_sin_mongo(self, test_config, mock_llm_router):
        mock_redis = AsyncMock()
        mock_redis.ping   = AsyncMock(return_value=True)
        mock_redis.lpush  = AsyncMock(return_value=1)
        mock_redis.rpop   = AsyncMock(return_value=None)
        mock_redis.aclose = AsyncMock()

        mock_repo = MagicMock()
        mock_repo.disponible = False  # ← Sin MongoDB

        with patch("main._redis", mock_redis), \
             patch("main.cfg", test_config), \
             patch("agents.llm_router._router", mock_llm_router):
            import main as app_module
            from utils.session_auth import SessionAuth
            app_module._session_auth = SessionAuth(test_config)
            app_module._redis = mock_redis
            app_module.app.state.repo = mock_repo

            with TestClient(app_module.app, raise_server_exceptions=True) as client:
                client.post(
                    "/login",
                    data={"username": "testuser", "password": "testpass"},
                    follow_redirects=False,
                )
                yield client

    def test_delete_sin_mongo_devuelve_503(self, client_sin_mongo):
        resp = client_sin_mongo.delete(f"/api/conversation/{_FAKE_OID}")
        assert resp.status_code == 503

    def test_patch_folder_sin_mongo_devuelve_503(self, client_sin_mongo):
        resp = client_sin_mongo.patch(
            f"/api/conversation/{_FAKE_OID}/folder",
            json={"folder": "Test"},
        )
        assert resp.status_code == 503

    def test_toggle_favorite_sin_mongo_devuelve_503(self, client_sin_mongo):
        resp = client_sin_mongo.post(f"/api/conversation/{_FAKE_OID}/favorite")
        assert resp.status_code == 503

    def test_canvas_save_sin_mongo_devuelve_503(self, client_sin_mongo):
        resp = client_sin_mongo.post("/api/canvas/save", json={
            "conversation_id": _FAKE_OID,
            "content": "code",
            "type": "code",
        })
        assert resp.status_code == 503
