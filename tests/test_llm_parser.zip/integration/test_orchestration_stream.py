"""
tests/integration/test_orchestration_stream.py
-------------------------------------------------
Tests de integración para:
  - process_query_stream() del OrchestrationAgent
  - Routing por agent_override (analyst / coder / researcher)
  - Comportamiento con agentes no-streaming (SSH, Jira)
  - Propagación de errores en el flujo streaming
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio


# ── Helpers ───────────────────────────────────────────────────────────────────

async def _collect_stream(gen):
    """Consume el async generator y separa chunks de texto del dict __done__."""
    chunks: list[str] = []
    done: dict | None = None
    async for item in gen:
        if isinstance(item, dict) and item.get("__done__"):
            done = item
        else:
            chunks.append(str(item))
    return chunks, done


def _make_classification(
    intention: str = "general",
    confidence: float = 0.9,
    follow_up: str | None = None,
    entities: dict | None = None,
):
    """Crea un objeto ClassificationResult mock."""
    cls = MagicMock()
    cls.intention = intention
    cls.confidence = confidence
    cls.follow_up_question = follow_up
    cls.entities = entities or {}
    return cls


def _make_agent_result(respuesta: str = "Resultado del agente", exito: bool = True):
    """Crea un AgentResult mock."""
    from agents.base_agent import AgentResult
    return AgentResult(
        respuesta=respuesta,
        exito=exito,
        agente="test_agent",
        datos={},
    )


# ── Fixture de orchestrator con mocks ─────────────────────────────────────────

@pytest.fixture
def orchestrator_with_mocks(mock_llm_router_stream):
    """
    OrchestrationAgent con todos los agentes y el IntentionAgent mockeados.
    Devuelve (orchestrator, mock_intention) para que los tests puedan configurar
    la clasificación que devuelve IntentionAgent.
    """
    mock_intention = MagicMock()

    with patch("agents.orchestration_agent.get_router", return_value=mock_llm_router_stream), \
         patch("agents.orchestration_agent.IntentionAgent", return_value=mock_intention), \
         patch("agents.orchestration_agent.SSHAgent"), \
         patch("agents.orchestration_agent.JiraAgent"), \
         patch("agents.orchestration_agent.WebAgent"):
        from agents.orchestration_agent import OrchestrationAgent
        orch = OrchestrationAgent()
        # Sustituir los agentes de modo por instancias con el mock_router
        from agents.analyst_agent import AnalystAgent
        from agents.coder_agent import CoderAgent
        from agents.researcher_agent import ResearcherAgent
        orch._mode_agents["analyst"]    = AnalystAgent(router=mock_llm_router_stream)
        orch._mode_agents["coder"]      = CoderAgent(router=mock_llm_router_stream)
        orch._mode_agents["researcher"] = ResearcherAgent(web_agent=None)
        orch._mode_agents["researcher"].router = mock_llm_router_stream
        return orch, mock_intention


# ═══════════════════════════════════════════════════════════════════════════════
# process_query_stream — flujo básico
# ═══════════════════════════════════════════════════════════════════════════════

class TestProcessQueryStreamBasic:

    @pytest.mark.asyncio
    async def test_stream_general_emite_chunks_y_done(self, orchestrator_with_mocks):
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(return_value=_make_classification("general"))

        gen = orch.process_query_stream("Hola", "testuser", [])
        chunks, done = await _collect_stream(gen)

        assert len(chunks) > 0                  # Al menos un chunk de texto
        assert done is not None                  # El evento __done__ llega
        assert done["result"].exito is True
        assert done["result"].intencion == "general"

    @pytest.mark.asyncio
    async def test_stream_texto_concatenado_es_respuesta_final(self, orchestrator_with_mocks):
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(return_value=_make_classification("general"))

        gen = orch.process_query_stream("Query de test", "testuser", [])
        chunks, done = await _collect_stream(gen)

        texto_total = "".join(chunks)
        assert texto_total == "Hola mundo streaming"  # Chunks del mock_llm_router_stream

    @pytest.mark.asyncio
    async def test_stream_done_contiene_agente_usado(self, orchestrator_with_mocks):
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(return_value=_make_classification("general"))

        gen = orch.process_query_stream("Query", "testuser", [])
        _, done = await _collect_stream(gen)

        assert done["result"].agente_usado  # No vacío

    @pytest.mark.asyncio
    async def test_stream_pasa_historial_a_classify(self, orchestrator_with_mocks):
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(return_value=_make_classification("general"))

        historial = [
            {"role": "user", "content": "Pregunta anterior"},
            {"role": "assistant", "content": "Respuesta anterior"},
        ]
        gen = orch.process_query_stream("Consulta nueva", "testuser", historial)
        await _collect_stream(gen)

        # classify recibe (user_query, historial)
        call_args = mock_intention.classify.call_args
        assert call_args.args[1] == historial or call_args.kwargs.get("historial") == historial


# ═══════════════════════════════════════════════════════════════════════════════
# process_query_stream — follow-up question
# ═══════════════════════════════════════════════════════════════════════════════

class TestProcessQueryStreamFollowUp:

    @pytest.mark.asyncio
    async def test_follow_up_emite_pregunta_como_chunk(self, orchestrator_with_mocks):
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(return_value=_make_classification(
            intention="diagnostico_servidor",
            follow_up="¿Cuál es el hostname del servidor?",
        ))

        gen = orch.process_query_stream("Revisar servidor", "testuser", [])
        chunks, done = await _collect_stream(gen)

        assert "¿Cuál es el hostname del servidor?" in chunks
        assert done is not None
        assert done["result"].agente_usado == "intention_followup"

    @pytest.mark.asyncio
    async def test_follow_up_no_llama_al_agente_especializado(self, orchestrator_with_mocks):
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(return_value=_make_classification(
            intention="diagnostico_servidor",
            follow_up="¿Cuál es el hostname?",
        ))
        ssh_mock = orch._agents.get("diagnostico_servidor") or MagicMock()
        ssh_mock.ejecutar = AsyncMock()
        orch._agents["diagnostico_servidor"] = ssh_mock

        gen = orch.process_query_stream("revisar server", "testuser", [])
        await _collect_stream(gen)

        ssh_mock.ejecutar.assert_not_called()


# ═══════════════════════════════════════════════════════════════════════════════
# process_query_stream — agent_override routing
# ═══════════════════════════════════════════════════════════════════════════════

class TestProcessQueryStreamAgentOverride:

    @pytest.mark.asyncio
    async def test_override_analyst_usa_analyst_agent(self, orchestrator_with_mocks):
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(return_value=_make_classification("general"))

        gen = orch.process_query_stream(
            "Consulta de análisis", "testuser", [], agent_override="analyst"
        )
        _, done = await _collect_stream(gen)

        assert "analyst" in done["result"].agente_usado.lower()

    @pytest.mark.asyncio
    async def test_override_coder_usa_coder_agent(self, orchestrator_with_mocks):
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(return_value=_make_classification("general"))

        gen = orch.process_query_stream(
            "Escribe código", "testuser", [], agent_override="coder"
        )
        _, done = await _collect_stream(gen)

        assert "coder" in done["result"].agente_usado.lower()

    @pytest.mark.asyncio
    async def test_override_researcher_usa_researcher_agent(self, orchestrator_with_mocks):
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(return_value=_make_classification("general"))

        gen = orch.process_query_stream(
            "Investiga Python", "testuser", [], agent_override="researcher"
        )
        _, done = await _collect_stream(gen)

        assert "researcher" in done["result"].agente_usado.lower()

    @pytest.mark.asyncio
    async def test_override_ignorado_para_intencion_ssh(self, orchestrator_with_mocks):
        """Si la intención es diagnostico_servidor, el override se ignora (SSH gana)."""
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(return_value=_make_classification(
            "diagnostico_servidor"
        ))

        ssh_mock = MagicMock()
        ssh_mock.ejecutar = AsyncMock(return_value=_make_agent_result("Diagnóstico SSH"))
        orch._agents["diagnostico_servidor"] = ssh_mock

        gen = orch.process_query_stream(
            "Revisa el servidor web01", "testuser", [], agent_override="analyst"
        )
        _, done = await _collect_stream(gen)

        ssh_mock.ejecutar.assert_called_once()
        # El agente_usado no debe ser el analyst
        assert "analyst" not in done["result"].agente_usado.lower()

    @pytest.mark.asyncio
    async def test_override_none_usa_generation_agent(self, orchestrator_with_mocks):
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(return_value=_make_classification("general"))

        gen = orch.process_query_stream(
            "Consulta general", "testuser", [], agent_override=None
        )
        _, done = await _collect_stream(gen)

        # Sin override, usa GenerationAgent
        assert done["result"].exito is True


# ═══════════════════════════════════════════════════════════════════════════════
# process_query_stream — agentes no-streaming (SSH, Jira)
# ═══════════════════════════════════════════════════════════════════════════════

class TestProcessQueryStreamNonStreamingAgents:

    @pytest.mark.asyncio
    async def test_agente_no_streaming_emite_respuesta_como_chunk(self, orchestrator_with_mocks):
        """SSH/Jira emiten su respuesta completa como un único chunk."""
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(
            return_value=_make_classification("diagnostico_servidor")
        )

        ssh_mock = MagicMock()
        ssh_mock.ejecutar = AsyncMock(
            return_value=_make_agent_result("CPU: 45% | RAM: 60%")
        )
        orch._agents["diagnostico_servidor"] = ssh_mock

        gen = orch.process_query_stream("Estado del servidor", "testuser", [])
        chunks, done = await _collect_stream(gen)

        assert "CPU: 45% | RAM: 60%" in chunks
        assert done["result"].respuesta == "CPU: 45% | RAM: 60%"
        assert done["result"].agente_usado == "test_agent"

    @pytest.mark.asyncio
    async def test_agente_jira_emite_respuesta(self, orchestrator_with_mocks):
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(
            return_value=_make_classification("crear_ticket_jira")
        )

        jira_mock = MagicMock()
        jira_mock.ejecutar = AsyncMock(
            return_value=_make_agent_result("Ticket PRJ-42 creado correctamente")
        )
        orch._agents["crear_ticket_jira"] = jira_mock

        gen = orch.process_query_stream("Crea un ticket", "testuser", [])
        chunks, done = await _collect_stream(gen)

        assert "PRJ-42" in "".join(chunks)
        assert done["result"].intencion == "crear_ticket_jira"


# ═══════════════════════════════════════════════════════════════════════════════
# process_query_stream — manejo de errores
# ═══════════════════════════════════════════════════════════════════════════════

class TestProcessQueryStreamErrors:

    @pytest.mark.asyncio
    async def test_excepcion_en_classify_devuelve_error_gracioso(self, orchestrator_with_mocks):
        """Una excepción inesperada debe producir __done__ con exito=False."""
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(side_effect=Exception("Error de red"))

        gen = orch.process_query_stream("Consulta", "testuser", [])
        chunks, done = await _collect_stream(gen)

        assert done is not None
        assert done["result"].exito is False
        assert done["result"].agente_usado == "orchestrator_error"

    @pytest.mark.asyncio
    async def test_excepcion_en_agente_devuelve_error_gracioso(self, orchestrator_with_mocks):
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(
            return_value=_make_classification("diagnostico_servidor")
        )

        ssh_mock = MagicMock()
        ssh_mock.ejecutar = AsyncMock(side_effect=RuntimeError("SSH connection refused"))
        orch._agents["diagnostico_servidor"] = ssh_mock

        gen = orch.process_query_stream("Conecta al servidor", "testuser", [])
        chunks, done = await _collect_stream(gen)

        assert done is not None
        assert done["result"].exito is False

    @pytest.mark.asyncio
    async def test_stream_siempre_termina_con_done(self, orchestrator_with_mocks):
        """Independientemente del resultado, el stream debe finalizar con __done__."""
        orch, mock_intention = orchestrator_with_mocks
        mock_intention.classify = AsyncMock(side_effect=ValueError("Fallo total"))

        gen = orch.process_query_stream("Query", "testuser", [])
        _, done = await _collect_stream(gen)

        assert done is not None  # __done__ siempre llega


# ═══════════════════════════════════════════════════════════════════════════════
# _resolver_agente — lógica de selección
# ═══════════════════════════════════════════════════════════════════════════════

class TestResolverAgente:
    """Tests unitarios del método _resolver_agente()."""

    @pytest.fixture
    def orch(self, orchestrator_with_mocks):
        orch, _ = orchestrator_with_mocks
        return orch

    def test_sin_override_general_devuelve_generation_agent(self, orch):
        from agents.generation_agent import GenerationAgent
        from agents.intention_agent import Intencion
        agente = orch._resolver_agente(Intencion.GENERAL, None)
        assert isinstance(agente, GenerationAgent)

    def test_override_analyst_con_general(self, orch):
        from agents.analyst_agent import AnalystAgent
        from agents.intention_agent import Intencion
        agente = orch._resolver_agente(Intencion.GENERAL, "analyst")
        assert isinstance(agente, AnalystAgent)

    def test_override_coder_con_general(self, orch):
        from agents.coder_agent import CoderAgent
        from agents.intention_agent import Intencion
        agente = orch._resolver_agente(Intencion.GENERAL, "coder")
        assert isinstance(agente, CoderAgent)

    def test_override_researcher_con_general(self, orch):
        from agents.researcher_agent import ResearcherAgent
        from agents.intention_agent import Intencion
        agente = orch._resolver_agente(Intencion.GENERAL, "researcher")
        assert isinstance(agente, ResearcherAgent)

    def test_override_ignorado_con_intencion_no_general(self, orch):
        """Para SSH/Jira/Web, el override analyst/coder/researcher se ignora."""
        from agents.ssh_agent import SSHAgent
        from agents.intention_agent import Intencion
        agente = orch._resolver_agente(Intencion.DIAGNOSTICO_SERVIDOR, "analyst")
        # No debe ser AnalystAgent — debe ser SSHAgent (o el mock que hayamos puesto)
        from agents.analyst_agent import AnalystAgent
        assert not isinstance(agente, AnalystAgent)

    def test_override_invalido_usa_generation_agent(self, orch):
        """Un override desconocido ('superagent') no debe romper el sistema."""
        from agents.generation_agent import GenerationAgent
        from agents.intention_agent import Intencion
        agente = orch._resolver_agente(Intencion.GENERAL, "superagent_inexistente")
        assert isinstance(agente, GenerationAgent)
